import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './LeaveList.css';

function LeaveList() {
  const [leaveData, setLeaveData] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/getLeaves')
      .then(response => {
        console.log(response);
        setLeaveData(response.data.Data);
      })
      .catch(error => {
        console.error('Error fetching leave data:', error);
      });
  }, []);

  return (
    <div>
      <table className="leave-table">
        <thead>
          <tr>
            <th>SNo.</th>
            <th>Leave Type</th>
            <th>From Date</th>
            <th>To Date</th>
            <th>Reason</th>
            <th>Approved / Rejected</th>
          </tr>
        </thead>
        <tbody>
          {leaveData.map((leave, index) => (
            <tr key={index}>
              <td>{index + 1}</td>
              <td>{leave.leaveType}</td>
              <td>{leave.startDate}</td>
              <td>{leave.endDate}</td>
              <td>{leave.reason}</td>
              <td>{leave.approvalStatus}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default LeaveList;